# Wardwell Coordinate — workflow, rules, and court watch

Reference for explaining how the guardianship board works. Written to be
readable aloud to a non-technical case coordinator.

## The 8 stages

Every case moves through these in order. No stage is skipped — a
corporate-funded case is *routed differently* at stage 4, not fast-tracked.

| # | Stage | Owner role | Required document(s) to leave the stage |
|---|-------|-----------|------------------------------------------|
| 1 | Request noted | Intake | Guardianship request logged |
| 2 | Capacity triage | Care team + facility | Capacity statement from facility |
| 3 | Medical documents | Medical records | Doctor's letter **and** guardianship questionnaire |
| 4 | Legal submission | Law firm (payer-routed) | Submission packet prepared |
| 5 | Filed with court | Law firm | Filing confirmation **and** the Legal Verified Receipt (LVR) |
| 6 | Court tracking | Law firm + care team | Hearing notice |
| 7 | Approved | Approver notified | Letters of guardianship |
| 8 | Guardian onboarding & accounts | Onboarding + guardian | Rep-payee account opened |

A case can also be **Dismissed** (leaves the active board, history kept) or
marked **Deceased** (closes cleanly — see R6).

## Escalation categories

Each case carries one, shown as a colored tag: **Standard**, **Escalated
(paid)**, **Tough case**, **Protective services**, or **Dismissed**. They tint
the card and drive the filter buttons above the board.

## Capacity, funding, representative

- **Capacity**: Needs guardianship / Can answer for themselves / Can sign only.
- **Funding (payer routing)**: Family (private pay) or Corporate-funded — this
  changes who coordinates at stage 4 (see R9).
- **Representative**: Family member / Professional guardian / Pending. A case
  cannot be approved while this is Pending (see R7).

## The rules engine (R1–R10)

The board enforces these automatically. They're deterministic — every action
names its own reason, no hidden logic.

- **R1 — Approver pinged once, at approval.** The Approver is notified only
  when a case reaches stage 7. One ping, at the end — never before.
- **R2 — Request noted opens the medical file.** Logging a request (stage 1)
  auto-creates a task to obtain the doctor's letter and the questionnaire.
- **R3 — Court watch auto-activates.** Entering stage 5 (Filed with court)
  turns on that case's court-watch entry automatically.
- **R4 — Approval starts guardian onboarding.** Reaching stage 7 sends the
  verification checklist to the guardian, notifies onboarding to close
  individual bank accounts and open a managed rep-payee account, and creates an
  external task-board sync entry.
- **R5 — No advance with missing docs or unverified receipt.** A case can't
  move while required documents are unchecked; stage 5 also requires the Legal
  Verified Receipt (LVR). The Advance button says exactly what's missing.
- **R6 — Deceased closes the case cleanly.** Marking a ward deceased stops
  future scheduled work (court watch, open tasks) and fires a single Billing
  notification ("case closed; reconcile billing"). History is preserved.
- **R7 — No approval with a pending representative.** A case can't reach
  stage 7 while the representative is Pending — guardianship must name who will
  act for the ward.
- **R8 — Medical documents complete → notify the law firm.** Reaching stage 4
  fires an automatic notification to the law firm to prepare and submit the
  petition.
- **R9 — Payer routing at legal submission.** Family (private pay): the law
  firm coordinates directly. Corporate-funded: the case is treated as a
  referral — the corporate payer coordinates the initial fee; a note is logged.
- **R10 — Court date confirmed → dated note.** When a reported hearing date is
  confirmed against the court record, a dated note is written to the case file.

## Court watch (the standout feature)

- When a case is filed (stage 5), court watch turns on for it (R3).
- A scheduled job checks the public court calendar on a per-case cadence:
  **Daily**, **Every 4 days**, or **Weekly**.
- When it finds a hearing date, it posts it as **"reported, not verified"** and
  sends a notification. It does **not** treat a found date as final — a person
  (or a later automated check) must confirm it against the court record, which
  writes a dated note (R10). This is deliberate: a hearing that was only
  mentioned on a phone call never silently becomes a hard deadline.
- In the demo, the court data is **simulated** (the "Run court watch now"
  button triggers a simulated check). In a real deployment a scheduled job does
  this from a server — see `setup-and-deploy.md`.

## CSV import columns

Header (exact): `case_name,facility,stage,category,funding,representative,filed_date,hearing_date,hearing_confirmed`

- `stage` must be 1–8; out-of-range rows are reported and skipped (they don't
  silently import wrong).
- `funding` accepts "Family (private pay)" / "Corporate-funded" (also matches
  on "family"/"corp").
- `representative` accepts "Pending", "Professional guardian", or "Family
  member (…relative…)".
- `hearing_confirmed` is yes/no; a stage-6 row with a date and "no" shows as
  reported-but-unverified.
- Unknown categories/funding default sensibly and produce a warning rather than
  failing the whole import.
