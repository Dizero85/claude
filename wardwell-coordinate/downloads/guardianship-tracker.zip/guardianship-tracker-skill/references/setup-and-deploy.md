# Running Wardwell Coordinate for real, and deploying it for a team

The single demo page (`assets/wardwell_demo.html`) is a **sandbox**: it runs
entirely in one person's browser, saves nothing, and shares nothing between
people. It's for *showing* the idea.

The **real tool** is a separate small application (Node.js + a SQLite
database). It has: a server-side rules engine, a real database that persists
cases, a scheduled court-watch job, real CSV import, and email alerts. That
project is delivered as a companion zip (`wardwell-coordinate.zip`) — it is
**not bundled inside this skill** to keep the skill lightweight. If you have
that project folder available, use it; if not, ask the person for it.

## Run it locally (one machine)

Requires Node.js 22 or newer.

```bash
npm install
npm run seed     # loads sample cases so the board isn't empty
npm start        # open http://localhost:3000
npm test         # optional: run the automated tests (should all pass)
```

This gives one person a working board on their own computer. Good for trying
the real thing, not yet shared with the team.

## Make it a shared tool for the whole team (deployment)

The app is already built for shared use — one database, rules on the server, a
scheduled job — so this is a **hosting step, not a rewrite**:

1. **Host it.** Put the project on a small cloud host (Render, Railway,
   Fly.io, a company VPS, or an internal server). Any host that runs a Node.js
   app works. Cost is small for a small team.
2. **One shared URL.** Everyone opens that one web address and sees and edits
   the **same** live board — same cases, saved, updated in real time.
3. **Turn on email alerts.** Set the SMTP settings in a `.env` file (there's an
   `.env.example` in the project showing every setting). Without it, alerts
   still fire but only get logged, not emailed.
4. **Data store.** SQLite (a single file) is fine for a small-team pilot. For a
   bigger rollout, switch to Postgres — the data layer is isolated in
   `src/store.js`, so it's a contained change, not a rewrite.

## The one unfinished piece: the real Utah court connection

Court watch currently runs on a **mock (fake) provider** by default, which is
why it works anywhere with no setup. The **real** Utah-court provider
(`src/services/courtWatch/utahCourtsProvider.js` in the project) is written but
**unverified** — it was built in an environment with no internet access to
`utcourts.gov`, so the exact request and page format were never captured.

To finish it (about half a day, on a normal internet connection):

1. Open Utah's public "Find a Hearing" court calendar in a browser, open the
   developer tools → Network tab, and run a real search for a known case/date.
2. Capture the exact request (URL, parameters) and the response HTML.
3. Update the two placeholder functions in `utahCourtsProvider.js` (marked
   `TODO(verify)`) to match what you captured.
4. Test it against a real case before switching any real case's provider from
   `mock` to `utah`.

Until that's done, keep the provider on `mock` and keep telling people the
court data is **simulated**. The scheduler, cadence, discovery, and
notification logic around it are already real and tested — only the actual
"read the Utah website" step needs finishing.
