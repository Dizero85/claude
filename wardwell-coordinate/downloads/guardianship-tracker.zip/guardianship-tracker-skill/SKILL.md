---
name: guardianship-tracker
description: >-
  Open, demonstrate, operate, or deploy the guardianship case-tracking board
  (working name "Wardwell Coordinate"). It does two things together: it keeps
  every long-term-care Medicaid guardianship case on one board through an
  8-stage pipeline, and it automatically watches the public court calendar for
  hearing dates so nobody checks the court website by hand. Use this skill
  whenever a team member wants to see or run the guardianship board, walk
  someone through the demo, track or advance a guardianship case, understand
  the case stages or the rules engine, import cases from a spreadsheet (CSV),
  check or explain the court-watch feature, or set the tool up so the whole
  team can use it. Trigger it even when the person doesn't say the tool's name
  — e.g. "show me the guardianship tracker," "how do our guardianship cases
  move through the system," "can you open that court-watch board," or "let's
  get the case board running for the team."
---

# Guardianship tracker (Wardwell Coordinate)

This is a tool for handling **long-term-care Medicaid guardianship cases**. It
does two things, and both matter equally:

1. **One board for every case.** Every guardianship case, every stage, every
   owner, and every deadline live in one place — replacing a workflow that's
   normally scattered across email, phone calls, and a spreadsheet, with an
   explicit rules engine so no case falls through the cracks.
2. **Court watch.** It checks the public court calendar automatically and posts
   hearing dates, so nobody has to look them up by hand.

"Wardwell Coordinate" is the tool's working name (it may be renamed). The demo
page still shows that name on screen.

## What a person usually wants

Most requests fall into one of these. Pick the matching path.

### 1. "Show me / open the board" (the most common request)

Open the bundled demo — it's a single self-contained web page that runs in
any browser with no server, no login, and no internet:

- The file is `assets/wardwell_demo.html` inside this skill.
- Open it in the browser (or tell the person to double-click it). If you have
  a way to render or serve a local HTML file, use it; otherwise give them the
  file path and say "double-click this to open it."

Walk them through both halves of the tool (the whole pitch in ~30 seconds):

**The board** (one place for every case):
1. Look across the 8 columns — every case, its stage, its owner, its deadline.
2. Click any case card, then **Advance stage**. If paperwork is missing it
   blocks and says exactly what's missing — that's the rules engine keeping a
   case from moving before it's ready.

**Court watch** (the calendar watched for you):
3. Scroll to the **Court watch** section. Point out **Robert Ashford** —
   status "Awaiting docket match," no hearing date yet.
4. Scroll up and click **"Run court watch now."**
5. Scroll back: Robert Ashford now shows a hearing date, tagged **"Reported,
   not verified,"** and a notification appears on the right. Nobody looked it
   up — the system found it.

The demo uses **synthetic (fake) data only** — invented names, no real client
or patient information.

### 2. "How does the workflow work?" / questions about stages, rules, court watch

Read `references/workflow.md` and answer from it. It has the 8 stages, the 10
rules the engine enforces (R1–R10), the escalation categories, and exactly how
court watch behaves (including why a found date is "reported, not verified"
until a human confirms it). Explain in plain language — the audience is often
non-technical case coordinators, not engineers.

### 3. "Import our cases from a spreadsheet"

The tool imports a CSV with this exact header:

```
case_name,facility,stage,category,funding,representative,filed_date,hearing_date,hearing_confirmed
```

A worked example is `assets/wardwell_demo.html`'s "Import cases (CSV)" button
(it ships an embedded sample). For column meanings and how bad rows are
handled, see `references/workflow.md`.

### 4. "Run it for real" / "set it up so the whole team can use it"

This is the important one to be honest about. Read
`references/setup-and-deploy.md` and follow it. The short version:

- The demo above is a **sandbox** — each person plays with their own copy;
  nothing is saved or shared.
- The **real tool** (a separate project with a database, server-side rules,
  and a scheduled court-watch job) is what a team uses together. To make it a
  shared, live board for everyone, it must be **hosted on a server** — that's
  a normal setup step, not a rebuild. See `references/setup-and-deploy.md`.
- One piece is **unfinished**: the connection to the *real* Utah court website.
  The code exists but was written without internet access to the court site,
  so it's untested. `references/setup-and-deploy.md` explains what to finish.

Do not tell anyone the court data is live yet — in the demo it is **simulated**.

## Honesty rules (important)

- Court data in the demo is **simulated**. The live Utah-court connection is
  written but **not yet verified**. Never present it as live.
- All names and figures are **synthetic**. There is no real client data here.
- This is a **prototype**, not legal advice, and not a certified system.

Keeping these straight protects the team from overselling it to a client or a
court.
